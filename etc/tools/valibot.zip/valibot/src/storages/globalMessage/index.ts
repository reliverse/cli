export * from './globalMessage.ts';
