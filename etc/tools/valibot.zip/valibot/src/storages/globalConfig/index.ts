export * from './globalConfig.ts';
