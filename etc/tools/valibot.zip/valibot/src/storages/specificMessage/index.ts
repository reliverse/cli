export * from './specificMessage.ts';
