export * from './emoji.ts';
