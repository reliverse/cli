export * from './mac48.ts';
