/**
 * Class type.
 */
export type Class = abstract new (...args: any) => any;
