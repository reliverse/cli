export const BLOCKED_KEYS = ['__proto__', 'prototype', 'constructor'];
