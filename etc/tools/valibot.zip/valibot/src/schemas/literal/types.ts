/**
 * Literal type.
 */
export type Literal = number | string | boolean | symbol | bigint;
