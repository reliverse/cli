import type { SchemaIssues } from '../../types/index.ts';

export interface TransformInfo {
  issues: SchemaIssues | undefined;
}
