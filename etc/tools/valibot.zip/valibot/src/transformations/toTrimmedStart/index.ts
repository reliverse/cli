export * from './toTrimmedStart.ts';
