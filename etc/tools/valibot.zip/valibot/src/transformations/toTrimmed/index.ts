export * from './toTrimmed.ts';
