export * from './toTrimmedEnd.ts';
